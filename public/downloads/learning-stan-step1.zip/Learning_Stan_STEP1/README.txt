Learning Stan: STEP 1 スターター
=====================================

このフォルダには、STEP 1「実データを読み、整える」で使う演習ノートと
入力データが、教材コードと同じ配置で入っています。

はじめ方
1. ZIPを右クリックして「すべて展開」します。
2. RStudioを開き、File > New Project > Existing Directoryを選びます。
3. 展開後の Learning_Stan_STEP1 フォルダをProjectに指定します。
4. 説明を読みながら進める場合はnb1-data.qmd、完成した一括処理を
   実行・編集する場合はstep1_analysis.Rを開きます。
5. 未導入の場合だけ、Consoleで次を1回実行します。
   install.packages(c("tidyverse", "readxl", "knitr", "rmarkdown"))
6. 上から順にコードを実行します。最後にoutput/condition_means.csvが
   3行3列で作成され、output/analysis_note.txtに分析対象・記述結果・
   限界の3行が保存されれば、中心課題は完了です。
7. 中心課題の後、step1-transfer.qmdで列名と条件名が異なるデータへ
   同じ品質方針を移します。step1_transfer_check.RのTRANSFER PASSが
   発展課題の完成条件です。

重要
- data/にある配布ファイル(raw)は上書きしません。
- 問題記録と検査済みデータはdata/processed/へ、要約結果はoutput/へ
  コードから生成します。これらのフォルダは実行時に自動作成されます。
- ファイルを手で直して結果を合わせず、コードを修正して再実行します。

教材サイト: https://ryuya-dot-com.github.io/Learning_Stan/
